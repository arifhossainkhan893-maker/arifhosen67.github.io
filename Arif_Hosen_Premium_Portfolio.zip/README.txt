ARIFHOSEN.COM — PORTFOLIO PACKAGE
=================================

Included:
- index.html: complete portfolio and Person structured data
- style.css: responsive premium black-and-white design
- script.js: mobile navigation and dynamic year
- arif-hosen-portrait.jpg: portrait supplied by the user

CV details were used as the content source. Please review all dates and wording before publishing.

BEFORE GOING LIVE
1. Register arifhosen.com with a domain registrar and arrange web hosting.
2. Upload all files to the hosting provider's public web root.
3. Confirm the site is served over HTTPS at https://arifhosen.com/.
4. Add the website to Google Search Console and submit a sitemap.
5. Add a public Facebook profile/page URL if you want it listed. It was not present in the supplied CV.
6. Confirm that the phone number and email should be publicly displayed before publishing.

The Person structured data is descriptive metadata only. It does not guarantee a Google Knowledge Panel.
This package does not purchase a domain, configure hosting, or publish the website.
